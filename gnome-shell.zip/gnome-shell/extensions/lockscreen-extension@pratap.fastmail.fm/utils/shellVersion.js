const Config = imports.misc.config;

var GNOME_SHELL_VERSION = Number(Config.PACKAGE_VERSION.split('.')[0]);